# Responsive slider timeline with Swiper

A Pen created on CodePen.io. Original URL: [https://codepen.io/bcarvalho/pen/RZqmZX](https://codepen.io/bcarvalho/pen/RZqmZX).

A responsive slider  timeline made with Swiper lib.